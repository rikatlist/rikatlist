---
layout: post
title: "Welcome to mnmlist-zen"
date: 2026-01-06
---

This is your first post using the **mnmlist-zen** theme. It is designed to be extremely simple, focused on typography and reading experience, just like Leo Babauta's Zen Habits.

### Why Minimalism?

Minimalism isn't about having nothing. It's about making room for what matters. In web design, that means:

1.  **No sidebars** to distract the reader.
2.  **Large, readable fonts** (Georgia).
3.  **Plenty of whitespace** to let the content breathe.

You can edit this post in the `_posts` folder or create new ones. Enjoy the simplicity.
